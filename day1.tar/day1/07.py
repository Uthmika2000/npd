#! /usr/bin/python

while True:
    x = input("Value :")
    print(x)
