#! /usr/bin/python
"""
for i in range(0, 10, 2):
    print(i)

for i in [1, 2, 3]:
    print(i)
fp = open('03.py','r')

for l in fp:
    line = l.strip()
    for c in line:
        print(c)
"""

a = 10
i = 0
while (True):
#while (1):
    print(i)
    i=i+1
    if (i == 5):
        break

while a > 5 :
    print(a)
    a=a-1


