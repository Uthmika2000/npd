#! /usr/bin/python

ages = {'a':11, 'b':10, 'c':33}
print(ages)
print(type(ages))

print(ages['b'])

