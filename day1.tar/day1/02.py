#! /usr/bin/python

str1 = 'abcd'
str2 = 'EFGH'

a = str1 + str2

print(a)

print(a.upper())
print(a.lower())
print(len(a))
print(len(str1))
print(len(str2))

print(a[4:])
print(a[:4])
print(a[::-1])
