#! /usr/bin/python

a = [1, 2, 4, 7, 5]
print(a)

a.sort()
print(a)

a.append('x')
print(a)

print(a.pop())
print(a)

a.insert(2, 'a')
print(a)

print(len(a))


a.remove(7)
print(a)

